package com.example.covid;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;

public class MainActivity extends AppCompatActivity {
    private Button Surv,Calendar,logout;

    //GoogleSignInClient mClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        logout = (Button)findViewById(R.id.logout);
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                GoBacktoSignin();
                //switch (v.getId()) {
                    // ...
                  //  case R.id.logout:
                    //    signOut();
                      //  break;
                    // ...
                //}
            }
        });

        Calendar = (Button)findViewById(R.id.Calender);
        Calendar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openCalendar();
            }
        });
        Surv = (Button)findViewById(R.id.Surv);
        Surv.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openSurvey();
            }
        });

    }
  /*  private void signOut(){
        mClient.revokeAccess()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        // ...
                       GoToSignin();
                    }
                });
        //Intent intent = new Intent(this,LoginActivity.class);
        //startActivity(intent);
    }
*/
    public void GoBacktoSignin(){
        Intent intent = new Intent(this,LoginActivity.class);
        startActivity(intent);
    }


    public void openCalendar(){
        Intent intent = new Intent(this,Calendar.class);
        startActivity(intent);
    }

    public void openSurvey(){
        Intent intent = new Intent(this,Survey.class);
        startActivity(intent);
    }

}
/*
    private void signOut() {
        mClient.signOut()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        // ...
                    }
                });
    }
*/

   /* private void signOut(){
        mClient.revokeAccess()
                .addOnCompleteListener(this, new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        // ...
                    }
                });
        //Intent intent = new Intent(this,LoginActivity.class);
        //startActivity(intent);
    }

}*/